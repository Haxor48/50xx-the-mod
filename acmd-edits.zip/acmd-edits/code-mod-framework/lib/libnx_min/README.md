# Nintendo Switch AArch64-only userland library.
Based on libctru.

[![Build status](https://doozer.io/badge/switchbrew/libnx/buildstatus/master)](https://doozer.io/switchbrew/libnx)

# Install instructions
See [Switchbrew](https://switchbrew.org/wiki/Setting_up_Development_Environment).
