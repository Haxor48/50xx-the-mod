#include <switch_min.h>

void print_string(u64 module_accessor, const char* format, ...);